
  # RCAP UI/UX Design System

  This is a code bundle for RCAP UI/UX Design System. The original project is available at https://www.figma.com/design/Ey9311gxCS5qVpMAYIVYmn/RCAP-UI-UX-Design-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  